<?php
return [
    'site_title' => 'eDominations',
    'site_description' => 'eDominations',
    'eDominationsAPI' => 'https://www.edominations.com/en/api',
    'eDominationsAPIv2' => 'https://www.edominations.com/en/api2'

];
